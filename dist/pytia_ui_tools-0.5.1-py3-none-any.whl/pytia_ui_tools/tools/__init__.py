"""
    Tools for tkinter apps.
"""
