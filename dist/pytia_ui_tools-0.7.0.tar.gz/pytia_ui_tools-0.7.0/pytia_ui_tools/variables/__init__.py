"""
    Variables for tkinter apps.
"""
