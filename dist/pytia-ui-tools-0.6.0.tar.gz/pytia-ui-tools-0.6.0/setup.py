# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pytia_ui_tools',
 'pytia_ui_tools.handlers',
 'pytia_ui_tools.helper',
 'pytia_ui_tools.models',
 'pytia_ui_tools.templates',
 'pytia_ui_tools.tools',
 'pytia_ui_tools.utils',
 'pytia_ui_tools.variables',
 'pytia_ui_tools.widgets']

package_data = \
{'': ['*']}

install_requires = \
['Jinja2==3.1.2',
 'Pillow==9.1.1',
 'PyYAML==6.0',
 'pyscreenshot==3.0',
 'pywin32==304',
 'qrcode==7.3.1']

setup_kwargs = {
    'name': 'pytia-ui-tools',
    'version': '0.6.0',
    'description': 'Helper functions and widgets for all pytia ui apps.',
    'long_description': '# pytia ui tools\n\nHelper functions and widgets for all pytia ui apps.\n\n![state](https://img.shields.io/badge/State-Alpha-brown.svg?style=for-the-badge)\n![version](https://img.shields.io/badge/Version-0.6.0-orange.svg?style=for-the-badge)\n\n[![python](https://img.shields.io/badge/Python-3.10-blue.svg?style=for-the-badge)](https://www.python.org/downloads/)\n![OS](https://img.shields.io/badge/OS-WIN10%20|%20WIN11-blue.svg?style=for-the-badge)\n\n> ✏️ This package only provides helper functions, widgets and some other stuff for all pytia ui apps. This package is therefore a required dependency for almost all pytia apps, but does nothing on its own.\n>\n> ⚠️ The layout of this app is heavily biased towards the workflow and needs of my companies\' engineering team.\n>\n> 🔒 This is currently a private repo.\n\nCheck out the pytia ecosystem:\n\n- [pytia](https://github.com/deloarts/pytia): The heart of this project.\n- [pytia-property-manager](https://github.com/deloarts/pytia-property-manager): An app to edit part and product properties.\n- [pytia-bounding-box](https://github.com/deloarts/pytia-bounding-box): An app to retrieve the bounding box of a part.\n- [pytia-bill-of-material](https://github.com/deloarts/pytia-bill-of-material): An app to retrieve the bill of material of a product.\n- [pytia-ui-tools](https://github.com/deloarts/pytia-ui-tools): A toolbox for all pytia apps.\n\n## 1 installation\n\n### 1.1 system requirements\n\n- Windows 10/11\n- [Python 3.10](https://www.python.org/downloads/)\n- MS Outlook (optional)\n\n### 1.2 pip\n\nTo pip-install this module you need to have access to this repo (which you obviously have if you can read this README). You then have two options:\n\n#### 1.2.1 access token\n\nCreate a [personal access token](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token) for pip\'ing it.\n\n```powershell\npython -m pip install git+https://${GITHUB_TOKEN}@github.com/deloarts/pytia-ui-tools.git{VERSION}\n```\n\nUse your access token instead of *GITHUB_TOKEN*.\nYou can omit the *VERSION*-tag if you want to install the latest version.\n\n#### 1.2.2 ssh\n\nCreate a [ssh key and add it to your github account](https://docs.github.com/en/authentication/connecting-to-github-with-ssh) for access. Make sure your ssh key is working:\n\n```powershell\nssh -T git@github.com\n```\n\n```powershell\npython -m pip install git+ssh://git@github.com/deloarts/pytia-ui-tools.git\n```\n\nIf you\'re using poetry add this to you **pyproject.toml** file:\n\n```toml\n[tool.poetry.dependencies]\npytia-ui-tools = { git = "ssh://git@github.com/deloarts/pytia-ui-tools.git", branch="main" }\n```\n\n## 2 developing\n\nFor developing you would, additionally to the system requirements, need to install:\n\n- [Poetry](https://python-poetry.org/docs/master/#installation)\n- [Git](https://git-scm.com/downloads) or [GitHub Desktop](https://desktop.github.com/)\n\n> ❗️ Never develop new features and fixes in the main branch!\n\n### 2.1 clone the repo\n\nClone the repo to your local machine:\n\n```powershell\ncd $HOME\nNew-Item -Path \'.\\git\\pytia-ui-tools\' -ItemType Directory\ncd .\\git\\pytia-ui-tools\\\ngit clone git@github.com:deloarts/pytia-ui-tools.git\n```\n\nOr use GitHub Desktop.\n\n### 2.2 poetry\n\n#### 2.2.1 setup\n\nIf you prefer the environment inside the projects root, use:\n\n```powershell\npoetry config virtualenvs.in-project true\n```\n\n> ⚠️ Make sure not to commit the virtual environment to GitHub. See [.gitignore](.gitignore) to find out which folders are ignored.\n\n#### 2.2.2 install\n\nInstall all dependencies (assuming you are inside the projects root folder):\n\n```powershell\npoetry install\n```\n\nCheck your active environment with:\n\n```powershell\npoetry env list\npoetry env info\n```\n\nUpdate dependencies with:\n\n```powershell\npoetry update\n```\n\n### 2.2.3 tests\n\nTests are done with pytest. Tests require a **tests.settings.json** file inside the [tests folder](tests/), which will be generated on your first run (or automatically on VS Code test discovery). Open this new file and fill out all required settings.\n\nFor testing with poetry run:\n\n```powershell\npoetry run pytest\n```\n\n> ⚠️ Test discovery in VS Code only works when CATIA is running.\n\n#### 2.2.4 build\n\n```powershell\npoetry build\n```\n\nThis exports the package to the [dist](/dist/) folder.\n\n> ⚠️ Make sure not to commit dev-builds (the dist folder isn\'t ignored, because this package isn\'t published on pip yet).\n\n### 2.3 pre-commit hooks\n\nDon\'t forget to install the pre-commit hooks:\n\n```powershell\npre-commit install\n```\n\n### 2.4 docs\n\nDocumentation is done with [pdoc3](https://pdoc3.github.io/pdoc/).\n\nTo update the documentation run:\n\n```powershell\npython -m pdoc --html --output-dir docs pytia_ui_tools\n```\n\nFor preview run:\n\n```powershell\npython -m pdoc --http : pytia_ui_tools\n```\n\n### 2.5 new revision checklist\n\nOn a new revision, do the following:\n\n1. Update **dependencies**: `poetry update`\n2. Update the **version** in\n   - [pyproject.toml](pyproject.toml)\n   - [__ init __.py](pytia_ui_tools/__init__.py)\n   - [README.md](README.md)\n3. Run all **tests**: `poetry run pytest`\n4. Check **pylint** output: `poetry run pylint pytia_ui_tools/`\n5. Update the **documentation**: `poetry run pdoc --force --html --output-dir docs pytia_ui_tools`\n6. Update the **lockfile**: `poetry lock`\n7. Update the **requirements.txt**: `poetry export --dev -f requirements.txt -o requirements.txt`\n8. **Build** the package: `poetry build`\n\n## 3 license\n\n[MIT License](LICENSE)\n\n## 4 changelog\n\n**v0.6.0**: Add file utility.  \n**v0.5.3**: Add drawing export folder to workspace model.  \n**v0.5.2**: Improve text editor.  \n**v0.5.1**: Fix workspace encoding.  \n**v0.5.0**: Add qr code functions.  \n**v0.4.1**: Add configure method to SnapScale.  \n**v0.4.0**: Add workspace handler.  \n**v0.3.1**: Fix ScrolledText widget.  \n**v0.3.0**: Add ScrolledText and text editor.  \n**v0.2.0**: Add NumberVar.  \n**v0.1.2**: Fix comma issue on NumberEntry.  \n**v0.1.1**: Bump pillow to 9.1.1.  \n**v0.1.0**: Initial commit.  \n\n## 5 to do\n\nUsing VS Code [Comment Anchors](https://marketplace.visualstudio.com/items?itemName=ExodiusStudios.comment-anchors) to keep track of to-dos.\n',
    'author': 'Philip Delorenzo',
    'author_email': 'git@deloarts.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
