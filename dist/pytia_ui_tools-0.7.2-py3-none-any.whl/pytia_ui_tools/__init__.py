"""
    **pytia_ui_tools**: Helper functions and widgets for all pytia ui apps.

    This package only provides helper functions, widgets and some other stuff for all pytia ui apps.
    This package is therefore a required dependency for almost all pytia apps, but does nothing on
    its own.

    https://github.com/deloarts/pytia-ui-tools
"""

__version__ = "0.7.2"
