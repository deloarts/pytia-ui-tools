"""
    Widgets for tkinter apps.
"""
