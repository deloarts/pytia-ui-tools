"""
    Template files for mailing.
"""
